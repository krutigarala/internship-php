<td align="center" valign="middle">
<div id="footer" Style="font-size:11px">
<a href="index.php">Home</a> - 
<a href="about_us.php">About Us</a> - 
<a href="registration.php">Donor Registration</a> - 
<a href="search_donor.php">Search Donors</a> - 
<a href="request.php">Request Blood</a> - 
<a href="contact_us.php"></a>
<a href="blood_tips.php">Blood Tips</a> - 
<a href="contact_us.php">Contact Us</a><br />Copyright &copy; 2020
<a href="index.php">Blood Bank India</a>. 
All Rights Reserved. Developed by Kruti
</td><td width="13" align="right"><img src="images/footer_right.gif" width="13" height="47" /></td></tr></table></td></tr><tr><td>&nbsp;</td></tr></table></td></tr></table></td></tr></table><map name="Map" id="Map"><area shape="rect" coords="5,7,46,23" href="index.php" /><area shape="rect" coords="54,7,105,24" href="register.php" /><area shape="rect" coords="114,7,177,23" href="contact_us.php" /></map></body></html>