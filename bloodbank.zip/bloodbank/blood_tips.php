<?php
include 'header.php';
?>
<tr>
<td height="335" align="center" valign="top"><div class="content" style=
"height:530"><b><u><h1 style="font-size:20px;">Blood Tips</u></b></h1><p>
<html>
<head>
<title></title>
</head>
<body>
<form action="" method="post">
<table border="" width="100%" height="">
<font color="#CC6600"size="+1"><b><p>
Beat the myth</font><br>
<font size="-1">Donating blood is safe and simple. It takes 
approximately 10-15 minutes to complete the blood donation process.Any healthy adult between 18 years and 60 years of age can donate blood.<br/>&nbsp;->You walk into a reputed and safe blood donation center or a &nbsp;&nbsp;&nbsp;&nbsp;mobile camp organized by a reputed institution.<br/>
&nbsp;->Blood will be separated into components within eight hours of &nbsp;&nbsp;&nbsp;&nbsp;donation.<br/>
<font color="#CC6600"size="+1"><br>
Blood Groups</font><br>
The ABO group has four categories namely.<br/>
1)A positive or A negative&nbsp;&nbsp;&nbsp;
2)B positive or B negative<br/>
3)O positive or O negative&nbsp;&nbsp;&nbsp;
4)AB positive or AB negative.<br/>
Type O individuals are often called "universal donors" and Type AB blood are called "universal 
recipients".
Do donate blood, only if you satisfy all of the following conditions:
<br/>
&nbsp;&nbsp;&nbsp;- You are between age group of 18-60 years.<br>
&nbsp;&nbsp;&nbsp;-Your weight is 45 kgs or more.<br>
&nbsp;&nbsp;&nbsp;-Your hemoglobin is 12.5 gm% minimum.<br>
&nbsp;&nbsp;&nbsp;-Your last blood donation was 3 or more months earlier.<br/>
</b></p>
</font>
</table>
</form>
</body>
</html>
</p>
</div>
</td>
<td width="10" style="background-color:#990000" valign="top">&nbsp;</td>
<?php
include 'side_client.php';
include 'footer.php';
?>