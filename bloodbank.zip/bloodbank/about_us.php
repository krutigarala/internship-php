<?php
include 'header.php';
?>
<tr >
<td height="455" align="center" valign="top"><div class="content" style="height:500"><b><u><h1 style="font-size:20px;">About Us</u></b></h1><p>
<html>
<head>
<title></title>
</head>
<body>
<form method="post" action="">
<table border="0" width="60%" height="50">
<font size="-1"><p><b>News Letter from the founders<br/><br/>
Ladies and Gentlemen!
<br/></br>
'Blood Bank India' is the first product resulted out of the community
 welfare initiative called 'People Project' from uSiS Technologies. Universally,
 'Blood' is recognized as the most precious element that sustains life. 
It saves innumerable lives across the world in a variety of conditions.
 Once in every 2-seconds, someone, somewhere is desperately in need of blood. 
More than 29 million units of blood components are transfused every year. 
The need for blood is great - on any given day, approximately 39,000 units of 
Red Blood Cells are needed. Each year, we could meet only up to 1% (approx) 
of our nation�s demand for blood transfusion.

Despite the increase in the number of donors, blood remains in short supply during emergencies,
mainly attributed to the lack of information and accessibility.We positively believe this tool
can overcome most of these challenges by effectively connecting the blood donors with the blood
recipients.
<br/>
Thank you and Happy Blood donating!
Blood Bank India.</b></p>
</font>
</table>
</form>
</body>
</html>
</p>
</div>
</td>
<td width="10" style="background-color:#990000" valign="top">&nbsp;</td>
<?php
include 'side_client.php';
include 'footer.php';
?>