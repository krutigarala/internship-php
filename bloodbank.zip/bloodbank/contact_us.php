<?php 
include 'header.php';
?>
<tr>
<td height="335" align="center" valign="top" ><div class="content" style="height:500"><b><u><h1 style="font-size:20px;">Contact Us</u></b></h1><p>
<html>
<head>
<title></title>
</head>
<body>
<form action="" method="post">
<table border="0" width="455" align="left">
<td align="center"><table border="0" width="250" align="left">
<tr><td align="center"><b><font color="Black" style="font-size:20px;">Call Us:</font></b></td>
</tr>
<tr><td>
<font color="Black" style="font-family:Monotype Corsiva;font-size:20px;">
We're available 24 hours a day.<br/>
(0285)2630672 or 2631672<br/>
98980 78978<br/></b>
</font>
</td>
</tr>
</table>
<tr>
<td align="center"><table border="0" width="250" align="left">
<tr><td align="center"><b><font color="Black" style="font-size:20px;">Mail Us:</font></b></td>
</tr>
<tr><td>
<font color="Black" style="font-family:Monotype Corsiva;font-size:20px;">
Vikram  Commercial Complex,<br/>
Sardar baug Road<br/>
Junagadh-362 001<br/>
E-Mail:drgkgajera@gmail.com<br></b>
</font>
</td>
</tr>
</table>
</tr>
</table>
</form>
</body>
</html>
</p>
</div>
</td>
<td width="10" style="background-color:#990000" valign="top">&nbsp;</td>
<?php
include 'side_client.php';
include 'footer.php';
?>