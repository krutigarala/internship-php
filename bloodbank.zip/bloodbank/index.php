<?php
include 'header.php';
?>
<tr>
<td height="335" align="center" valign="top"><div class="content">
<b><h1 style="font-size:20px;">Welcome to Blood Bank India</b></h1><p>
<html>
<head>
<title></title>
</head>
<body bgcolor="red">
<form>
<table border="0" align="center" height="500" width="800">
	<tr valign="top"><center>
	<td colspan="2" width="800"><?php include 'index.html';?>
	</td>
	</tr><br>
	<tr>
<td><img src="images/blooddonate.jpg" width="250" height="200">
</td>
<td><br><br><br><b><font size="-1">Blood is universally recognized as the most precious element that sustains
life. It saves innumerable lives across the world in a variety of conditions. 
The need for blood is great - on any given day, approximately 39,000 units of 
Red Blood Cells are needed. More than 29 million units of blood components are 
transfused every year.	 	
Despite the increase in the number of donors, blood remains in short supply
during emergencies, mainly attributed to the lack of information and accessibility.

We positively believe this tool can overcome most of these challenges by
effectively connecting the blood donors with the blood recipients.
<br><br><font color="#990000" size="3px">
What You Should Eat Before Donating</font><br><br>

A healthy diet helps ensure a successful blood donation, and also makes you feel
better! Check out the following recommended foods to eat prior to your donation.<br><br>
           &nbsp;&nbsp;&nbsp;>> Low fat foods<br>
           &nbsp;&nbsp;&nbsp;>> Iron rich foods</font>
</b></td>
</tr>
</table>
</form>
</body>
</html>
</p>
</div>
</td>
<?php
include 'footer.php';
?>